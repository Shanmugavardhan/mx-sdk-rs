use multiversx_sc::derive_imports::*;

use multiversx_sc::types::TimestampMillis;
use multiversx_sc::{
    api::ManagedTypeApi,
    types::{BigUint, ManagedAddress},
};

#[type_abi]
#[derive(NestedEncode, NestedDecode, TopEncode, TopDecode)]
pub enum AuctionType {
    Selling,
    Siring,
}

#[type_abi]
#[derive(NestedEncode, NestedDecode, TopEncode, TopDecode)]
pub struct Auction<M: ManagedTypeApi> {
    pub auction_type: AuctionType,
    pub starting_price: BigUint<M>,
    pub ending_price: BigUint<M>,
    pub deadline: TimestampMillis,
    pub kitty_owner: ManagedAddress<M>,
    pub current_bid: BigUint<M>,
    pub current_winner: ManagedAddress<M>,
}

impl<M: ManagedTypeApi> Auction<M> {
    pub fn new(
        auction_type: AuctionType,
        starting_price: BigUint<M>,
        ending_price: BigUint<M>,
        deadline: TimestampMillis,
        kitty_owner: ManagedAddress<M>,
    ) -> Self {
        Auction {
            auction_type,
            starting_price,
            ending_price,
            deadline,
            kitty_owner,
            current_bid: BigUint::zero(),
            current_winner: ManagedAddress::zero(),
        }
    }
}
